# J.A.R.V.I.S. Fire TV — Phase 1

A native Kotlin Android TV-style dashboard starter project for Amazon Fire TV Stick.

## Included
- Fullscreen landscape dashboard
- Animated custom-drawn reactor
- Live clock/date
- Status panels
- Focusable buttons navigable with the Fire TV remote D-pad and Select button
- No external UI dependencies

## Build an APK
1. Install Android Studio on a computer.
2. Open this `JARVIS-FIRETV` folder using **File > Open**.
3. Install a compatible Android SDK (API 35) when Android Studio prompts.
4. Use JDK 17 (Android Studio's embedded JDK is suitable).
5. Wait for Gradle sync to finish.
6. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Fire TV Stick
1. On Fire TV, open **Settings > My Fire TV > About**.
2. Select the device name repeatedly until Developer Options are enabled (wording varies by Fire OS version).
3. In **Developer Options**, enable ADB Debugging and install unknown apps for the downloader/file manager you use.
4. Install a reputable Downloader app or transfer the APK over your local network.
5. Open the APK with a file manager and approve installation.
6. Launch J.A.R.V.I.S. from your apps list.

Alternative using ADB from a computer on the same network:
`adb connect FIRE_TV_IP:5555`
`adb install -r app/build/outputs/apk/debug/app-debug.apk`

ADB availability and the port can vary by Fire OS version. Use the address and pairing flow shown by your Fire TV if it requires pairing.

## Compatibility notes
- `minSdk 23` is a broad Android baseline; actual Fire OS support depends on the Fire TV model and firmware.
- `targetSdk 28` is intentionally conservative for this sideloaded prototype; app-store publishing has different target API requirements.
- `compileSdk 35`, Android Gradle Plugin 8.9.2, Kotlin 2.1.20 and JDK 17 are used.
- The Leanback launcher category is included but marked optional.
- This is Phase 1 UI only. The voice button is a placeholder. No microphone capture, speech recognition, AI API, or smart-home control is connected yet.
- Fire TV remote voice keys are controlled by Fire OS and are not guaranteed to deliver microphone audio to a sideloaded app. Phase 2 must test the exact Fire TV model and may use a phone companion app or a separate microphone device.
- No OpenAI API key is embedded in the app. A later backend should keep secrets server-side.

## Project status
Source project prepared. It must be built with Android Studio to produce the APK. No prebuilt APK is included.
