package com.jarvis.firetv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.cos
import kotlin.math.sin

class ReactorView(context: Context) : View(context) {
    private val handler = Handler(Looper.getMainLooper())
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.035f
            if (phase > 6.28318f) phase = 0f
            invalidate()
            handler.postDelayed(this, 33L)
        }
    }

    fun startAnimation() {
        if (!running) {
            running = true
            handler.post(tick)
        }
    }

    fun stopAnimation() {
        running = false
        handler.removeCallbacks(tick)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (height.coerceAtMost(width) * 0.34f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2.2f

        for (i in 0..3) {
            paint.color = when (i) {
                0 -> 0xFF00D8FF.toInt()
                1 -> 0xAA00AACC.toInt()
                2 -> 0x7760DFFF.toInt()
                else -> 0x5560DFFF.toInt()
            }
            val r = radius * (0.42f + i * 0.19f)
            canvas.drawCircle(cx, cy, r, paint)
        }

        paint.color = 0xFF00D8FF.toInt()
        paint.strokeWidth = 3f
        val arc = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.drawArc(arc, phase * 57.2958f, 95f, false, paint)
        canvas.drawArc(arc, 180f - phase * 57.2958f, 65f, false, paint)

        paint.style = Paint.Style.FILL
        paint.color = 0xFF06283A.toInt()
        canvas.drawCircle(cx, cy, radius * 0.38f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = 0xFF48E8FF.toInt()
        paint.strokeWidth = 2.5f
        canvas.drawCircle(cx, cy, radius * (0.27f + 0.025f * sin(phase * 2)), paint)

        paint.style = Paint.Style.FILL
        paint.color = 0xFFB8F7FF.toInt()
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 19f
        paint.typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD
        )
        canvas.drawText("J.A.R.V.I.S.", cx, cy + 7f, paint)

        paint.color = 0xFF00CFFF.toInt()
        for (i in 0 until 12) {
            val angle = phase + i * (Math.PI / 6.0)
            val x1 = cx + cos(angle).toFloat() * radius * 0.88f
            val y1 = cy + sin(angle).toFloat() * radius * 0.88f
            val x2 = cx + cos(angle).toFloat() * radius * 0.98f
            val y2 = cy + sin(angle).toFloat() * radius * 0.98f
            paint.strokeWidth = 3f
            canvas.drawLine(x1, y1, x2, y2, paint)
        }
    }
}
