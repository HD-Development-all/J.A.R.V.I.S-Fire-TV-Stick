package com.jarvis.firetv

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val cyan = Color.rgb(0, 210, 255)
    private val muted = Color.rgb(145, 170, 190)
    private lateinit var clockView: TextView
    private lateinit var statusView: TextView
    private lateinit var reactor: ReactorView
    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            clockView.text = SimpleDateFormat(
                "EEEE  •  dd MMM yyyy  •  HH:mm:ss", Locale.getDefault()
            ).format(Date())
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildDashboard()
        handler.post(clockTick)
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(42, 18, 42, 22)
            setBackgroundColor(Color.rgb(3, 9, 18))
            isFocusable = true
        }

        val header = TextView(this).apply {
            text = "J.A.R.V.I.S.   //   PERSONAL ASSISTANT"
            textSize = 19f
            letterSpacing = 0.18f
            setTextColor(cyan)
            gravity = Gravity.CENTER
        }
        clockView = TextView(this).apply {
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 9, 0, 3)
        }

        reactor = ReactorView(this).apply {
            contentDescription = "Animated JARVIS reactor core"
        }

        statusView = TextView(this).apply {
            text = "SYSTEM READY  •  LOCAL DEMO"
            textSize = 14f
            letterSpacing = 0.12f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 12)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val statusCard = infoCard("SYSTEM STATUS", "ONLINE\nAI CORE: DEMO\nNETWORK: CHECKED BY ANDROID")
        val commandCard = infoCard("COMMAND CENTER", "Use the remote to select a command.\nVoice and AI connection are Phase 2.")
        row.addView(statusCard, LinearLayout.LayoutParams(0, 116, 1f).apply { marginEnd = 10 })
        row.addView(commandCard, LinearLayout.LayoutParams(0, 116, 1f).apply { marginStart = 10 })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val talk = actionButton("VOICE MODULE") {
            statusView.text = "VOICE MODULE NOT CONFIGURED — PHASE 2"
        }
        val diagnose = actionButton("SYSTEM DIAGNOSTICS") {
            statusView.text = "DIAGNOSTICS: UI OK • AI NOT CONNECTED • VOICE NOT CONNECTED"
        }
        actions.addView(talk, LinearLayout.LayoutParams(0, 54, 1f).apply { marginEnd = 10 })
        actions.addView(diagnose, LinearLayout.LayoutParams(0, 54, 1f).apply { marginStart = 10 })

        root.addView(header)
        root.addView(clockView)
        root.addView(reactor, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 230
        ))
        root.addView(statusView)
        root.addView(row)
        root.addView(actions)

        setContentView(root)
        talk.requestFocus()
    }

    private fun infoCard(title: String, body: String): TextView =
        TextView(this).apply {
            text = "$title\n\n$body"
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(185, 215, 230))
            setBackgroundColor(Color.rgb(8, 23, 37))
            setPadding(18, 12, 18, 10)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            isFocusable = true
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(0, 75, 105))
            setOnClickListener { action() }
            setOnFocusChangeListener { view, focused ->
                view.alpha = if (focused) 1f else 0.78f
                view.scaleX = if (focused) 1.035f else 1f
                view.scaleY = if (focused) 1.035f else 1f
            }
        }

    override fun onResume() {
        super.onResume()
        handler.post(clockTick)
        reactor.startAnimation()
    }

    override fun onPause() {
        handler.removeCallbacks(clockTick)
        reactor.stopAnimation()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
